import numpy as np

def transform(grid):
    arr = np.array(grid)
    # Find indices of all non-zero elements
    nonzero_indices = np.argwhere(arr != 0)
    if len(nonzero_indices) == 0:
        return []
    
    # Determine the bounding box of non-zero elements
    min_r, min_c = nonzero_indices.min(axis=0)
    max_r, max_c = nonzero_indices.max(axis=0)
    
    # Crop the grid to the bounding box
    cropped = arr[min_r:max_r+1, min_c:max_c+1]
    
    return cropped.tolist()

import numpy as np
from scipy.ndimage import label

def transform(grid):
    grid = np.array(grid)
    
    # Find connected components of color 6
    mask = (grid == 6)
    labeled, num_features = label(mask)
    
    components = []
    for i in range(1, num_features + 1):
        r_indices, c_indices = np.where(labeled == i)
        min_r, max_r = r_indices.min(), r_indices.max()
        min_c, max_c = c_indices.min(), c_indices.max()
        center_r = r_indices.mean()
        center_c = c_indices.mean()
        
        comp_pixels = set(zip(r_indices, c_indices))
        non_zero_pixels = np.argwhere((grid != 0) & (grid != 6))
        
        best_marker = 0
        min_dist = float('inf')
        for pr, pc in non_zero_pixels:
            d = min(abs(pr - cr) + abs(pc - cc) for cr, cc in comp_pixels)
            if d < min_dist:
                min_dist = d
                best_marker = grid[pr, pc]
                
        components.append({
            'min_row': min_r,
            'min_col': min_c,
            'center_r': center_r,
            'center_c': center_c,
            'marker': best_marker
        })
        
    # Determine layout: vertical or horizontal
    center_rs = [c['center_r'] for c in components]
    center_cs = [c['center_c'] for c in components]
    span_r = max(center_rs) - min(center_rs) if center_rs else 0
    span_c = max(center_cs) - min(center_cs) if center_cs else 0
    
    subgrids = []
    if span_r >= span_c:
        components.sort(key=lambda x: x['min_row'])
        for c in components:
            sub = grid[c['min_row']:c['min_row']+4, c['min_col']:c['min_col']+4]
            out_sub = np.zeros((4, 4), dtype=int)
            out_sub[sub == 6] = c['marker']
            subgrids.append(out_sub)
        output = np.vstack(subgrids)
    else:
        components.sort(key=lambda x: x['min_col'])
        for c in components:
            sub = grid[c['min_row']:c['min_row']+4, c['min_col']:c['min_col']+4]
            out_sub = np.zeros((4, 4), dtype=int)
            out_sub[sub == 6] = c['marker']
            subgrids.append(out_sub)
        output = np.hstack(subgrids)
        
    return output.tolist()
